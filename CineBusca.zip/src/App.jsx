import { useEffect, useMemo, useState } from "react";
import "./App.css";

const API_KEY = import.meta.env.VITE_TMDB_API_KEY?.trim();
const API = "/api/tmdb"; // O proxy opcional no servidor evita expor a chave; fallback direto para protótipo.
const DIRECT_API = "https://api.themoviedb.org/3";
const IMG = "https://image.tmdb.org/t/p/w500";
const BACKDROP = "https://image.tmdb.org/t/p/w1280";
const PROVIDER_LOGO = "https://image.tmdb.org/t/p/w92";

async function tmdb(path) {
  if (!API_KEY) throw new Error("Configure sua chave TMDB: copie .env.example para .env.local e preencha VITE_TMDB_API_KEY.");
  const url = `${DIRECT_API}${path}${path.includes("?") ? "&" : "?"}api_key=${encodeURIComponent(API_KEY)}&language=pt-BR`;
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 401) throw new Error("Chave do TMDB inválida ou não autorizada. Confira sua chave e reinicie o servidor.");
    if (response.status === 429) throw new Error("Limite de requisições atingido. Aguarde um pouco e tente novamente.");
    throw new Error(`Falha ao consultar TMDB (HTTP ${response.status}).`);
  }
  return response.json();
}

const providerGroups = [
  ["flatrate", "Incluído na assinatura"],
  ["free", "Grátis"],
  ["ads", "Grátis com anúncios"],
  ["rent", "Aluguel"],
  ["buy", "Compra"]
];

const streamNames = [
  "Netflix", "Amazon Prime Video", "Disney Plus", "Max", "Globoplay",
  "Apple TV", "Paramount Plus", "MUBI", "Claro video", "Crunchyroll",
  "Looke", "Telecine"
];

function readStorage(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function App() {
  const [movies, setMovies] = useState([]);
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(null);
  const [providers, setProviders] = useState(null);
  const [favorites, setFavorites] = useState(() => readStorage("cinebusca-favorites", []));
  const [watchlist, setWatchlist] = useState(() => readStorage("cinebusca-watchlist", []));
  const [subscribed, setSubscribed] = useState(() => readStorage("cinebusca-services", []));
  const [providerList, setProviderList] = useState([]);
  const [genreList, setGenreList] = useState([]);
  const [genre, setGenre] = useState("");
  const [year, setYear] = useState("");
  const [minRating, setMinRating] = useState("0");
  const [sortBy, setSortBy] = useState("popularity.desc");
  const [view, setView] = useState("home");
  const [loading, setLoading] = useState(false);
  const [detailLoading, setDetailLoading] = useState(false);
  const [error, setError] = useState("");
  const [dark, setDark] = useState(() => readStorage("cinebusca-theme", true));
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => { localStorage.setItem("cinebusca-favorites", JSON.stringify(favorites)); }, [favorites]);
  useEffect(() => { localStorage.setItem("cinebusca-watchlist", JSON.stringify(watchlist)); }, [watchlist]);
  useEffect(() => { localStorage.setItem("cinebusca-services", JSON.stringify(subscribed)); }, [subscribed]);
  useEffect(() => { localStorage.setItem("cinebusca-theme", JSON.stringify(dark)); }, [dark]);

  useEffect(() => {
    Promise.all([
      tmdb("/genre/movie/list"),
      tmdb("/watch/providers/movie?watch_region=BR")
    ]).then(([genresData, providerData]) => {
      setGenreList(genresData.genres || []);
      setProviderList(providerData.results || []);
    }).catch((err) => setError(err.message));
    loadPopular();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadPopular() {
    setLoading(true);
    setError("");
    setView("home");
    try {
      const data = await tmdb("/movie/popular?region=BR&page=1");
      setMovies(data.results || []);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function searchMovies(event) {
    event?.preventDefault();
    if (!query.trim()) return loadPopular();
    setLoading(true); setError(""); setSelected(null); setView("search");
    try {
      const data = await tmdb(`/search/movie?query=${encodeURIComponent(query.trim())}&region=BR&include_adult=false&page=1`);
      setMovies(data.results || []);
      if (!data.results?.length) setError("Nenhum filme encontrado. Tente outro título.");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function applyFilters(event) {
    event?.preventDefault();
    setLoading(true); setError(""); setSelected(null); setView("discover");
    const params = new URLSearchParams({
      region: "BR",
      sort_by: sortBy,
      include_adult: "false",
      "vote_average.gte": minRating || "0",
      page: "1"
    });
    if (genre) params.set("with_genres", genre);
    if (year) params.set("primary_release_year", year);
    if (subscribed.length) params.set("with_watch_providers", subscribed.join("|"));
    if (subscribed.length) params.set("watch_region", "BR");
    try {
      const data = await tmdb(`/discover/movie?${params.toString()}`);
      setMovies(data.results || []);
      if (!data.results?.length) setError("Nenhum filme corresponde a esses filtros. Tente alterar os critérios.");
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }

  async function openMovie(movie) {
    setSelected(movie); setProviders(null); setDetailLoading(true); setError("");
    try {
      const [details, watch] = await Promise.all([
        tmdb(`/movie/${movie.id}?append_to_response=credits`),
        tmdb(`/movie/${movie.id}/watch/providers`)
      ]);
      setSelected(details);
      setProviders(watch.results?.BR || null);
    } catch (err) { setError(err.message); }
    finally { setDetailLoading(false); }
  }

  function toggleIn(list, setter, movie) {
    setter((current) => current.some((item) => item.id === movie.id)
      ? current.filter((item) => item.id !== movie.id)
      : [...current, {
          id: movie.id, title: movie.title, poster_path: movie.poster_path,
          release_date: movie.release_date, vote_average: movie.vote_average
        }]);
  }

  const isIn = (list, movie) => list.some((item) => item.id === movie.id);
  const director = selected?.credits?.crew?.find((person) => person.job === "Director");
  const displayedMovies = useMemo(() => {
    if (view === "favorites") return favorites;
    if (view === "watchlist") return watchlist;
    if (subscribed.length && view !== "search" && view !== "favorites" && view !== "watchlist") {
      // Os filtros de descoberta consultam os serviços no servidor TMDB; esta verificação visual
      // não substitui a disponibilidade individual exibida nos detalhes.
      return movies;
    }
    return movies;
  }, [view, favorites, watchlist, movies, subscribed]);

  function setSection(next) {
    setView(next); setSelected(null); setError("");
    if (next === "home") loadPopular();
  }

  return (
    <div className={`app ${dark ? "theme-dark" : "theme-light"}`}>
      <header className="header">
        <button className="brand" onClick={() => setSection("home")} aria-label="CineBusca início">
          <span className="brand-icon">▶</span><span>CINE<b>BUSCA</b></span>
        </button>
        <nav className="main-nav">
          <button className={view === "home" ? "nav-active" : ""} onClick={() => setSection("home")}>Início</button>
          <button className={view === "discover" ? "nav-active" : ""} onClick={() => { setFiltersOpen(true); setSection("discover"); }}>Explorar</button>
          <button className={view === "favorites" ? "nav-active" : ""} onClick={() => setSection("favorites")}>♥ Favoritos <small>{favorites.length}</small></button>
          <button className={view === "watchlist" ? "nav-active" : ""} onClick={() => setSection("watchlist")}>＋ Quero assistir <small>{watchlist.length}</small></button>
        </nav>
        <form className="search" onSubmit={searchMovies}>
          <span aria-hidden="true">⌕</span>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Filme, ator ou diretor..." aria-label="Buscar filme" />
          <button type="submit">Buscar</button>
        </form>
        <button className="theme-toggle" onClick={() => setDark((value) => !value)} aria-label="Alternar tema">{dark ? "☼" : "☾"}</button>
      </header>

      {!selected && view === "home" && (
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow"><i /> SEU GUIA DE CINEMA</span>
            <h1>Seu próximo filme.<br /><em>Sem perder tempo.</em></h1>
            <p>Descubra histórias incríveis e saiba onde assistir no Brasil. Tudo em um só lugar.</p>
            <div className="hero-actions">
              <button className="primary" onClick={() => { setFiltersOpen(true); document.getElementById("filters")?.scrollIntoView({ behavior: "smooth" }); }}>Explorar catálogo <span>→</span></button>
              <button className="secondary" onClick={() => document.querySelector(".search input")?.focus()}>⌕ Buscar título</button>
            </div>
            <div className="hero-stats"><span><b>01</b> Pesquise</span><span><b>02</b> Compare</span><span><b>03</b> Assista</span></div>
          </div>
          <div className="hero-art" aria-hidden="true">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="art-card art-card-back"><span>STREAMING</span><b>SEU CINEMA<br />EM UM SÓ LUGAR</b></div>
            <div className="art-card art-card-front"><span className="play-mark">▶</span><small>PRÓXIMA SESSÃO</small><strong>Escolha sua<br />próxima história.</strong><i>DISCOVER SOMETHING NEW</i></div>
            <div className="art-glow" />
          </div>
        </section>
      )}

      {!selected && (
        <section className="filters-panel" id="filters">
          <div className="filters-top">
            <div><span className="eyebrow">ENCONTRE SEU FILME</span><h2>Explore por preferência</h2></div>
            <button className="text-button" onClick={() => setFiltersOpen((v) => !v)}>{filtersOpen ? "Recolher filtros ↑" : "Mostrar filtros ↓"}</button>
          </div>
          {filtersOpen && (
            <form className="filters-grid" onSubmit={applyFilters}>
              <label>Gênero
                <select value={genre} onChange={(e) => setGenre(e.target.value)}>
                  <option value="">Todos os gêneros</option>
                  {genreList.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
                </select>
              </label>
              <label>Ano de lançamento
                <input type="number" min="1900" max="2100" placeholder="Ex.: 2025" value={year} onChange={(e) => setYear(e.target.value)} />
              </label>
              <label>Nota mínima
                <select value={minRating} onChange={(e) => setMinRating(e.target.value)}>
                  <option value="0">Qualquer nota</option><option value="5">5 ou mais</option><option value="6">6 ou mais</option><option value="7">7 ou mais</option><option value="8">8 ou mais</option>
                </select>
              </label>
              <label>Ordenar por
                <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                  <option value="popularity.desc">Mais populares</option>
                  <option value="vote_average.desc">Melhores avaliados</option>
                  <option value="primary_release_date.desc">Lançamentos recentes</option>
                  <option value="revenue.desc">Maior bilheteria</option>
                </select>
              </label>
              <label className="service-filter">Seus streamings
                <select value={subscribed.join("|")} onChange={(e) => setSubscribed(e.target.value ? e.target.value.split("|").map(Number) : [])}>
                  <option value="">Todos os serviços</option>
                  {providerList.map((p) => <option key={p.provider_id} value={p.provider_id}>{p.provider_name}</option>)}
                </select>
              </label>
              <button className="primary filter-submit" type="submit">Aplicar filtros →</button>
              <p className="filter-note">A disponibilidade por serviço depende dos dados regionais do TMDB e pode mudar.</p>
            </form>
          )}
          {!filtersOpen && (
            <div className="quick-services">
              <span>Serviços populares no Brasil</span>
              {streamNames.slice(0, 6).map((name) => <span className="service-chip" key={name}>{name}</span>)}
            </div>
          )}
        </section>
      )}

      {selected ? (
        <main className="details">
          <button className="back-button" onClick={() => { setSelected(null); setProviders(null); }}>← Voltar ao catálogo</button>
          <div className="detail-layout">
            {selected.poster_path ? <img className="detail-poster" src={`${IMG}${selected.poster_path}`} alt={`Pôster de ${selected.title}`} /> : <div className="detail-poster no-poster">Pôster indisponível</div>}
            <div className="detail-info">
              <span className="eyebrow">DETALHES DO FILME</span>
              <h1>{selected.title}</h1>
              {selected.original_title !== selected.title && <p className="muted">{selected.original_title}</p>}
              <div className="metadata"><span className="rating-text">★ {selected.vote_average?.toFixed(1) || "—"} / 10</span><span>{selected.release_date?.slice(0, 4) || "Ano desconhecido"}</span>{selected.runtime > 0 && <span>{selected.runtime} min</span>}</div>
              <div className="genre-list">{(selected.genres || []).map((g) => <span key={g.id}>{g.name}</span>)}</div>
              <h3>Sinopse</h3><p className="overview">{selected.overview || "Sinopse não disponível em português."}</p>
              {director && <p><b>Direção:</b> {director.name}</p>}
              <p><b>Elenco:</b> {selected.credits?.cast?.slice(0, 6).map((p) => p.name).join(", ") || "Não disponível"}</p>
              <div className="detail-actions">
                <button className="primary" onClick={() => toggleIn(favorites, setFavorites, selected)}>{isIn(favorites, selected) ? "♥ Nos favoritos" : "♡ Favoritar"}</button>
                <button className="secondary" onClick={() => toggleIn(watchlist, setWatchlist, selected)}>{isIn(watchlist, selected) ? "✓ Na lista" : "+ Quero assistir"}</button>
              </div>
            </div>
          </div>
          <section className="providers">
            <div className="providers-heading"><div><span className="eyebrow">DISPONIBILIDADE NO BRASIL</span><h2>Onde assistir?</h2></div><span className="live-label"><i /> Dados TMDB</span></div>
            {detailLoading && <p className="status">Consultando provedores...</p>}
            {!detailLoading && providers && !providerGroups.some(([key]) => providers[key]?.length) && <p className="empty-state">Nenhum provedor foi listado para este filme no Brasil neste momento.</p>}
            {!detailLoading && providers && providerGroups.map(([key, label]) => {
              const items = providers[key] || [];
              if (!items.length) return null;
              return <div className="provider-section" key={key}><h3>{label}</h3><div className="provider-list">{items.map((p) => <div className="provider" key={p.provider_id}>{p.logo_path && <img src={`${PROVIDER_LOGO}${p.logo_path}`} alt="" loading="lazy" />}<span>{p.provider_name}</span>{subscribed.includes(p.provider_id) && <b className="subscribed-tag">Você assina</b>}</div>)}</div></div>;
            })}
            {providers?.link && <a className="provider-link" href={providers.link} target="_blank" rel="noreferrer">Ver opções e disponibilidade ↗</a>}
            <p className="muted small">A disponibilidade pode mudar. Confirme os detalhes no serviço antes de assistir.</p>
          </section>
        </main>
      ) : (
        <main className="catalog">
          <div className="section-heading">
            <div><span className="eyebrow">{view === "favorites" ? "SUA COLEÇÃO" : view === "watchlist" ? "PARA DEPOIS" : view === "search" ? "RESULTADOS DA BUSCA" : view === "discover" ? "CATÁLOGO PERSONALIZADO" : "ESCOLHAS PARA VOCÊ"}</span><h2>{view === "favorites" ? "Seus favoritos" : view === "watchlist" ? "Quero assistir" : view === "search" ? "Filmes encontrados" : view === "discover" ? "Explore filmes" : "Filmes populares"}</h2></div>
            <span className="result-count">{displayedMovies.length} títulos</span>
          </div>
          {error && <div className="notice"><b>Ops!</b> {error}</div>}
          {loading && <div className="loading-state"><span className="spinner" /> Buscando filmes...</div>}
          {!loading && !displayedMovies.length && !error && <div className="empty-state">{view === "favorites" ? "Você ainda não favoritou filmes. Explore o catálogo e toque no coração." : view === "watchlist" ? "Sua lista está vazia. Adicione os filmes que deseja ver depois." : "Nenhum filme para exibir."}</div>}
          <div className="movie-grid">
            {displayedMovies.map((movie) => <article className="movie-card" key={movie.id}>
              <div className="poster-wrap">
                <button className="poster-button" onClick={() => openMovie(movie)} aria-label={`Ver detalhes de ${movie.title}`}>
                  {movie.poster_path ? <img src={`${IMG}${movie.poster_path}`} alt={`Pôster de ${movie.title}`} loading="lazy" /> : <div className="no-poster">Pôster indisponível</div>}
                  <span className="poster-overlay">Ver detalhes ↗</span>
                </button>
                <button className={`heart ${isIn(favorites, movie) ? "active" : ""}`} onClick={() => toggleIn(favorites, setFavorites, movie)} aria-label={isIn(favorites, movie) ? "Remover dos favoritos" : "Adicionar aos favoritos"}>{isIn(favorites, movie) ? "♥" : "♡"}</button>
                <span className="rating">★ {movie.vote_average?.toFixed(1) || "—"}</span>
                <button className={`watch-add ${isIn(watchlist, movie) ? "watch-added" : ""}`} onClick={() => toggleIn(watchlist, setWatchlist, movie)} aria-label="Adicionar à lista para assistir">{isIn(watchlist, movie) ? "✓" : "+"}</button>
              </div>
              <button className="movie-title" onClick={() => openMovie(movie)}>{movie.title}</button>
              <p className="year">{movie.release_date?.slice(0, 4) || "Ano desconhecido"}</p>
            </article>)}
          </div>
          {!selected && view !== "favorites" && view !== "watchlist" && movies.length > 0 && (
            <div className="more-row"><button className="secondary" onClick={() => { setFiltersOpen(true); document.getElementById("filters")?.scrollIntoView({ behavior: "smooth" }); }}>Refinar busca e filtros ↓</button></div>
          )}
        </main>
      )}

      <footer className="footer">
        <div className="footer-brand"><span className="brand-icon">▶</span><b>CINEBUSCA</b></div>
        <p>Seu guia para descobrir onde assistir.</p>
        <p className="legal">Este produto utiliza a API do TMDB, mas não é endossado ou certificado pelo TMDB. A disponibilidade de streaming é fornecida pelos dados do TMDB/JustWatch.</p>
        <a href="https://www.themoviedb.org/" target="_blank" rel="noreferrer" className="tmdb-credit">Dados de filmes fornecidos por <b>THE MOVIE DATABASE (TMDB)</b></a>
      </footer>
    </div>
  );
}

export default App;
